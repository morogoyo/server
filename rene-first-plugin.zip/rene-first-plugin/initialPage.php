/**
 * Plugin Name: My First plugin
 * Plugin URI: http://localhost/testSite
 * Description: just a test plugin
 * Version: 1.0.0
 * Author: Daniel Pataki
 * Author URI: http://localhost/testSite
 * License: GPL2
 */